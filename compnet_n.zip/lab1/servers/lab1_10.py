#10.The client sends to the server two strings. 
# The server sends back the character with the largest number of occurrences on the same positions in both strings together with its count. -tcp
#server

import socket
import pickle

host = '192.168.1.8'
port = 12345

def get_max_occurrences(strings):
    str1, str2 = strings
    max_occurrences = 0
    max_char = ''
    for i in range(len(str1)):
        if str1[i] == str2[i]:
            occurrences = str1.count(str1[i])
            if occurrences > max_occurrences:
                max_occurrences = occurrences
                max_char = str1[i]
    return (max_char, max_occurrences)

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print('Server is listening...')
    conn, addr = s.accept()
    print('Connection address:', addr)
    data = conn.recv(1024)
    strings = pickle.loads(data)
    result = get_max_occurrences(strings)
    conn.sendall(pickle.dumps(result))
    conn.close()
    s.close()
    print('Connection closed')

if __name__ == '__main__':
    main()