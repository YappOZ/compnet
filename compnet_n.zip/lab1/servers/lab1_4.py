#4.   The client sends to the server two sorted array of chars. The server will merge sort the two arrays and return the result to the client. -tcp
#server

import socket
import pickle

host = '192.168.1.8'
port = 12345

def merge_sort(arr1, arr2):
    arr = []
    i, j = 0, 0
    while i < len(arr1) and j < len(arr2):
        if arr1[i] < arr2[j]:
            arr.append(arr1[i])
            i += 1
        else:
            arr.append(arr2[j])
            j += 1
    while i < len(arr1):
        arr.append(arr1[i])
        i += 1
    while j < len(arr2):
        arr.append(arr2[j])
        j += 1
    return arr

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print('Server is listening...')
    while True:
        conn, addr = s.accept()
        print('Connected to', addr)
        data = conn.recv(1024)
        arr1, arr2 = pickle.loads(data)
        print('Received:', arr1, arr2)
        result = merge_sort(arr1, arr2)
        conn.sendall(pickle.dumps(result))
        conn.close()
        print('Connection closed')
        break

if __name__ == '__main__':
    main()