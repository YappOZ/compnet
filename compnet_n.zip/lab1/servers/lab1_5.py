#5.   The client sends to the server an integer. The server returns the list of divisors for the specified number. -tcp
#server

import socket
import pickle

host = '192.168.1.8'
port = 12345

def divisors(n):
    return [i for i in range(1, n + 1) if n % i == 0]

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print('Server is listening...')
    while True:
        conn, addr = s.accept()
        print('Connected to', addr)
        data = conn.recv(1024)
        number = pickle.loads(data)
        print('Received:', number)
        result = divisors(number)
        conn.sendall(pickle.dumps(result))
        conn.close()
        print('Connection closed')
        break

if __name__ == '__main__':
    main()