#1.   A client sends to the server an array of numbers. Server returns the sum of the numbers. -tcp
##server

import socket
import pickle

host = '192.168.1.8'
port = 12345

def sum_of_array(arr):
    return sum(arr)

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print('Server is listening...')
    try:
        while True:
            conn, addr = s.accept()
            print('Connected to', addr)
            data = conn.recv(1024)
            arr = pickle.loads(data)
            print('Received:', arr)
            result = sum_of_array(arr)
            conn.sendall(str(result).encode())
            conn.close()
            print('Connection closed')
            break
    except KeyboardInterrupt:
        s.close()
        print('Server closed')
    finally:
        s.close()
        print('Server closed')

if __name__ == '__main__':
    main()