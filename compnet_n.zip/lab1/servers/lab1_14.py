#14.The client sends an array of boolean values. The server counts how many true values are in the array and returns the count.. -tcp
#server

import socket
import pickle

host = '192.168.1.8'
port = 12345

def count_true(array):
    return array.count(True)

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print('Server is listening...')
    conn, addr = s.accept()
    print('Connection address: ', addr)
    data = conn.recv(1024)
    array = pickle.loads(data)
    result = count_true(array)
    conn.sendall(pickle.dumps(result))
    conn.close()
    s.close()
    print('Connection closed')

if __name__ == '__main__':
    main()
