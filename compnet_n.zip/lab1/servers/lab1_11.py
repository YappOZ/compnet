#11.Define a simple structure (e.g., a Person object with firstname, lastname, gender  and age). 
# The client sends this structure to the server. The server increments the age and sends the updated structure back. -tcp
#server

import socket
import pickle

host = '192.168.1.8'
port = 12345

class Person:
    def __init__(self, firstname, lastname, age):
        self.firstname = firstname
        self.lastname = lastname
        self.age = age
    
    def __str__(self):
        return f'{self.firstname} {self.lastname} {self.age}'
    
    def increment_age(self):
        self.age += 1

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print('Server is listening...')
    conn, addr = s.accept()
    print('Connection address: ', addr)
    data = conn.recv(4096)
    person = pickle.loads(data)
    person.increment_age()
    conn.sendall(pickle.dumps(person))
    conn.close()
    s.close()
    print('Connection closed')

if __name__ == '__main__':
    main()