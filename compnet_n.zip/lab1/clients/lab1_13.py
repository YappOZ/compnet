#13.The client sends a small text file to the server. The server saves the file and returns the length of the received file content as an unsigned integer -tcp
#client

import socket
import pickle

host = '192.168.1.8'
port = 12345

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    
    with open('file.txt', 'rb') as f:
        data = f.read()
        s.sendall(pickle.dumps(data))
        length = pickle.loads(s.recv(1024))
        print('Length of received file content: ', length)
    s.close()

if __name__ == '__main__':
    main()