#7.   The client sends to the server a string and two numbers (s, I, l). The sever returns to the client the substring of s starting at index I, of length l. -tcp
#client

import socket
import pickle

host = '192.168.1.8'
port = 12345

def main():
    string = 'Hello, world!'
    i = 7
    l = 5
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    s.sendall(pickle.dumps((string, i, l)))
    data = s.recv(1024)
    result = pickle.loads(data)
    print('Substring:', result)
    s.close()

if __name__ == '__main__':
    main()