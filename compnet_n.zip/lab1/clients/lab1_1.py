#1.   A client sends to the server an array of numbers. Server returns the sum of the numbers. -tcp
##client

import socket
import pickle

host = '192.168.1.8'
port = 12345

def main():
    arr = [1, 2, 3, 4, 5]
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    s.sendall(pickle.dumps(arr))
    data = s.recv(1024)
    result = data.decode()
    print('Sum:', result)
    s.close()

if __name__ == '__main__':
    main()
