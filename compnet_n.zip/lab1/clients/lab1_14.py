#14.The client sends an array of boolean values. The server counts how many true values are in the array and returns the count.. -tcp
#client

import socket
import pickle

host = '192.168.1.8'
port = 12345

def main():
    array = [True, False, True, False, True]
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    s.sendall(pickle.dumps(array))
    data = s.recv(1024)
    count = pickle.loads(data)
    print('Number of true values:', count)
    s.close()

if __name__ == '__main__':
    main()