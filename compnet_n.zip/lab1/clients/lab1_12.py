#12.The client sends a date string in YYYY-MM-DD format. The server returns the day of the week corresponding to that date. -tcp
#client

import socket
import datetime
import pickle

host = '192.168.1.8'
port = 12345

def main():
    date = '2024-11-17'
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    s.sendall(pickle.dumps(date))
    data = s.recv(1024)
    day = pickle.loads(data)
    print('Day of the week: ', day)
    s.close()

if __name__ == '__main__':
    main()