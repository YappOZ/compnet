#3.   The server chooses a random float number <SRF>. Run multiple clients. Each client chooses a random float number <CRF> and send it to the server. 
#  When the server does not receive any incoming connection for at least 10 seconds 
# it chooses the client that has guessed the best approximation (is closest) for its own number and sends it 
# back the message “You have the best guess with an error of <SRV>-<CRF>”. 
# It also sends to each other client the string “You lost !”. The server closes all connections after this. -threads/processes
#client

import socket
import random
import pickle

host = '192.168.1.8'
port = 12345

def main():
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((host, port))
        
        # Generate a random float and send it to the server
        client_random_float = random.uniform(0, 100)
        print("Client generated float:", client_random_float)
        
        client.send(pickle.dumps(client_random_float))
        
        # Wait for the server's response without closing the connection prematurely
        print("Waiting for the server's response...")
        message = client.recv(1024).decode()
        print("Message from server:", message)
        
    except Exception as e:
        print("An error occurred:", e)
    finally:
        client.close()
        print("Connection closed.")

if __name__ == "__main__":
    main()

