import socket
import threading
import time
from datetime import datetime
from queue import Queue, Full

# Configuration
PORT = 7777
BUFFER_SIZE = 1024
TIMEQUERY = "TIMEQUERY\0"
DATEQUERY = "DATEQUERY\0"
MALFORMED_QUEUE_LIMIT = 10
MALFORMED_DISPLAY_LIMIT = 10

# Peer tracking
peers = {}
malformed_messages = Queue(maxsize=MALFORMED_QUEUE_LIMIT)

# Mutex for safe peer access
peers_lock = threading.Lock()

# Broadcast function for TIMEQUERY and DATEQUERY
def broadcast_message(broadcast_ip, message, interval):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    
    while True:
        time.sleep(interval)
        sock.sendto(message.encode(), (broadcast_ip, PORT))


# Listener function to receive UDP packets
def listen_for_messages():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(('', PORT))
    
    while True:
        data, addr = sock.recvfrom(BUFFER_SIZE)
        handle_message(data.decode().strip(), addr, sock)

# Handle incoming UDP messages
def handle_message(message, addr, sock):
    global malformed_messages
    
    if message == TIMEQUERY:
        current_time = datetime.now().strftime("TIME %H:%M:%S\0")
        sock.sendto(current_time.encode(), addr)
        update_peers(addr, time=True)
    elif message == DATEQUERY:
        current_date = datetime.now().strftime("DATE %d:%m:%Y\0")
        sock.sendto(current_date.encode(), addr)
        update_peers(addr, date=True)
    else:
        # Malformed message handling
        if malformed_messages.full():
            malformed_messages.get()
        malformed_messages.put(f"{addr[0]}:{addr[1]} - {message}")

# Update peer status or add new peers
def update_peers(addr, time=False, date=False):
    with peers_lock:
        ip = addr[0]  # Track by IP only
        if ip not in peers:
            peers[ip] = {'port': addr[1], 'time': None, 'date': None, 'missed': 0}
        
        if time:
            peers[ip]['time'] = datetime.now().strftime("%H:%M:%S")
            peers[ip]['missed'] = 0  # Reset missed count on response
        if date:
            peers[ip]['date'] = datetime.now().strftime("%d:%m:%Y")
            peers[ip]['missed'] = 0  # Reset missed count on response

        # Update port if changed (optional, for display purposes)
        peers[ip]['port'] = addr[1]

        # Display the current peer list
        display_peers()

import os

# Display the list of peers and malformed messages
def display_peers():
    # Clear the screen windows and linux with if statements
    os.system('cls' if os.name == 'nt' else 'clear')
    
    print("Current Peers:")
    for ip, data in peers.items():
        print(f"{ip}:{data['port']:<20} TIME {data['time']}   DATE {data['date']}")
    
    print("\nMalformed Messages:")
    for i in list(malformed_messages.queue)[-MALFORMED_DISPLAY_LIMIT:]:
        print(i)


# Remove peers that haven't responded to multiple broadcasts
def cleanup_peers():
    while True:
        time.sleep(3)
        with peers_lock:
            for ip_port in list(peers.keys()):
                peers[ip_port]['missed'] += 1
                if peers[ip_port]['missed'] >= 3:
                    del peers[ip_port]
            display_peers()

if __name__ == "__main__":
    import sys
    if len(sys.argv) != 2:
        print("Usage: python serv.py <NBCAST>")
        sys.exit(1)
    
    broadcast_ip = sys.argv[1]

    # Start threads
    try:
        threading.Thread(target=listen_for_messages, daemon=True).start()
        threading.Thread(target=broadcast_message, args=(broadcast_ip, TIMEQUERY, 3), daemon=True).start()
        threading.Thread(target=broadcast_message, args=(broadcast_ip, DATEQUERY, 10), daemon=True).start()
        threading.Thread(target=cleanup_peers, daemon=True).start()
    except Exception as e:
        print(f"Error starting threads: {e}")

    while True:
        time.sleep(1)  # Keep main thread alive
