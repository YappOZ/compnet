import socket
import threading
import time

def simulate_client(client_id, broadcast_ip):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        local_port = 5000 + client_id  # Use unique source ports for each client
        sock.bind(('192.168.1.8', local_port))  # Replace with your actual local IP

        # Send TIMEQUERY every 3 seconds
        while True:
            try:
                sock.sendto("TIMEQUERY\0".encode(), (broadcast_ip, 7777))
                data, addr = sock.recvfrom(1024)
                print(f"Client {client_id} received from {addr}: {data.decode().strip()}")
            except OSError as e:
                print(f"Client {client_id} encountered error: {e}")
            time.sleep(3)

    except Exception as e:
        print(f"Error in client {client_id}: {e}")

# Start multiple client threads
broadcast_ip = "192.168.1.255"  # Replace with your network's broadcast address
num_clients = 3  # Number of clients to simulate

for i in range(num_clients):
    threading.Thread(target=simulate_client, args=(i, broadcast_ip)).start()
