#4.   Implement the Chat server example (see the link bellow) using UDP and TCP –only this time each client should contact the server just for registration. 
# All communication happens directly between the peers (clients) without passing trough the server. 
# Each client maintains an endpoint (TCP/UDP) with the server just for learning the arrival/departure of other clients. 
# You create a mesh architecture where all clients connect directly between each others. 

#---------------------CLIENT---------------------
import socket
import pickle
import sys
import threading
import time

class ChatClient:
    def __init__(self, server_ip='192.168.1.8', server_port=12345, client_port=0):
        self.server_ip = server_ip
        self.server_port = server_port
        self.client_port = client_port
        self.active_peers = set()
        self.lock = threading.Lock()
        self.socket = None
        self.running = True
        self.local_address = None

    def setup_socket(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind(('', self.client_port))
        self.local_address = (self.server_ip, self.client_port)
        return self.socket

    def update_peers(self, new_peers):
        """Update the peer list and print only if there are changes"""
        with self.lock:
            old_peers = self.active_peers.copy()
            # Filter out our own address from the peer list
            self.active_peers = {peer for peer in new_peers if peer[1] != self.client_port}
            if old_peers != self.active_peers:
                print("\nPeer list updated:")
                print("Active peers:", self.active_peers)
                print("Enter message: ", end='', flush=True)

    def listen_for_updates(self):
        """Listens for updates from the server and updates the active_peers set."""
        while self.running:
            try:
                data, addr = self.socket.recvfrom(1024)
                if addr == (self.server_ip, self.server_port):
                    try:
                        peers = pickle.loads(data)
                        self.update_peers(peers)
                    except Exception as e:
                        print(f"Error processing peer update: {e}")
            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    print(f"Update listener error: {e}")

    def message_handler(self):
        """Handles sending messages to other clients."""
        while self.running:
            try:
                message = input("Enter message: ")
                if message.lower() == "exit":
                    self.running = False
                    break
                
                with self.lock:
                    peers = self.active_peers.copy()
                
                if not peers:
                    print("No active peers to send message to.")
                    continue

                for peer in peers:
                    try:
                        print(f"Sending message to peer: {peer}")
                        self.socket.sendto(message.encode('utf-8'), peer)
                    except Exception as e:
                        print(f"Failed to send message to {peer}: {e}")
            except Exception as e:
                if self.running:
                    print(f"Message handler error: {e}")

    def receive_messages(self):
        """Handles receiving messages from other clients."""
        while self.running:
            try:
                data, addr = self.socket.recvfrom(1024)
                # Only process non-server messages
                if addr != (self.server_ip, self.server_port):
                    print(f"\nMessage from {addr}: {data.decode('utf-8')}")
                    print("Enter message: ", end='', flush=True)
            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    print(f"Message receiver error: {e}")

    def run(self):
        self.setup_socket()
        self.socket.settimeout(0.1)

        # Register with server and request initial peer list
        register_data = pickle.dumps("REGISTER")
        self.socket.sendto(register_data, (self.server_ip, self.server_port))
        print(f"Registered with server at {self.server_ip}:{self.server_port}")
        print(f"Local address: {self.local_address}")

        # Start threads
        threads = [
            threading.Thread(target=self.listen_for_updates),
            threading.Thread(target=self.receive_messages),
            threading.Thread(target=self.message_handler)
        ]
        
        for thread in threads:
            thread.daemon = True
            thread.start()

        # Keep requesting peer updates periodically
        try:
            while self.running:
                # Periodically request peer list updates
                self.socket.sendto(pickle.dumps("REGISTER"), (self.server_ip, self.server_port))
                time.sleep(5)  # Request update every 5 seconds
        except KeyboardInterrupt:
            self.running = False

        # Cleanup
        try:
            self.socket.sendto(pickle.dumps("UNREGISTER"), (self.server_ip, self.server_port))
            print("\nUnregistered from server.")
        finally:
            self.socket.close()
            for thread in threads:
                thread.join(timeout=1.0)

def main():
    if len(sys.argv) < 2:
        print("Usage: python client.py <client_port>")
        return
    
    client_port = int(sys.argv[1])
    client = ChatClient(client_port=client_port)
    client.run()

if __name__ == "__main__":
    main()