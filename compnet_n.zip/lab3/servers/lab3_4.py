#4.   Implement the Chat server example (see the link bellow) using UDP and TCP –only this time each client should contact the server just for registration. 
# All communication happens directly between the peers (clients) without passing trough the server. 
# Each client maintains an endpoint (TCP/UDP) with the server just for learning the arrival/departure of other clients. 
# You create a mesh architecture where all clients connect directly between each others. 

#---------------------UDP SERVER---------------------
import socket
import pickle

class ChatServer:
    def __init__(self, ip='192.168.1.8', port=12345):
        self.ip = ip
        self.port = port
        self.clients = set()
        self.socket = None
        self.running = True

    def broadcast_update(self):
        """Broadcasts the updated client list to all registered clients."""
        # Convert client addresses to use actual IP instead of 0.0.0.0
        normalized_clients = {(self.ip, client[1]) for client in self.clients}
        data = pickle.dumps(normalized_clients)
        
        for client in self.clients:
            try:
                print(f"Sending peer update to {client}: {normalized_clients}")
                self.socket.sendto(data, client)
            except Exception as e:
                print(f"Failed to send update to {client}: {e}")

    def run(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind((self.ip, self.port))
        print(f"Server listening on {self.ip}:{self.port}")
        
        while self.running:
            try:
                data, addr = self.socket.recvfrom(1024)
                command = pickle.loads(data)
                
                if command == "REGISTER":
                    # Normalize the client address to use server's IP
                    normalized_addr = (self.ip, addr[1])
                    if normalized_addr not in {(self.ip, client[1]) for client in self.clients}:
                        self.clients.add(addr)
                        print(f"Client {addr} registered.")
                        # Broadcast to all clients immediately after registration
                elif command == "UNREGISTER":
                    if addr in self.clients:
                        self.clients.remove(addr)
                        print(f"Client {addr} unregistered.")
                else:
                    print(f"Unknown command from {addr}: {command}")
                self.broadcast_update()
            except Exception as e:
                print(f"Error: {e}")

    def stop(self):
        self.running = False
        if self.socket:
            self.socket.close()

def main():
    server = ChatServer()
    try:
        server.run()
    except KeyboardInterrupt:
        print("\nServer shutting down gracefully...")
        server.stop()

if __name__ == "__main__":
    main()