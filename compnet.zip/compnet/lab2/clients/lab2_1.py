#1.   The client takes a string from the command line and sends it to the server. 
# The server interprets the string as a command with its parameters. 
# It executes the command and returns the standard output and the exit code to the client. -threads/processes
#client

import socket
import sys
import signal

def signal_handler(sig, frame):
    print('Signal handler called with signal', sig)
    sys.exit(0)

def main():
    signal.signal(signal.SIGINT, signal_handler)
    host = input('Enter server IP (default 192.168.1.8): ') or '192.168.1.8'
    port = int(input('Enter port (default 12345): ') or 12345)
    
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client.connect((host, port))
    except (socket.error, ConnectionRefusedError) as e:
        print(f"Connection failed: {e}")
        sys.exit(1)

    while True:
        command = input('Enter command: ')
        if command == 'exit':
            client.send(command.encode('utf-8'))
            print("Exiting...")
            break
        
        client.send(command.encode('utf-8'))
        data = b''
        while True:
            part = client.recv(4096)  # Increased buffer size for larger outputs
            data += part
            if len(part) < 4096:  # End of data
                break
        
        print(data.decode('utf-8'))

    client.close()

if __name__ == '__main__':
    main()