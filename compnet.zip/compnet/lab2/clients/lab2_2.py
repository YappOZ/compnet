#
# 2.   The client sends the complete path to a file. The server returns back the length of the file and its content in the case the file exists.
# When the file does not exist the server returns a length of -1 and no content. 
# The client will store the content in a file with the same name as the input file with the suffix –copy appended (ex: for f.txt => f.txt-copy). -threads/processes
#client

import socket
import os

host = '192.168.1.8'
port = 12345

def main():
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((host, port))
    file_path = input("Enter the complete path to a file: ")
    client.send(file_path.encode())
    file_size = int(client.recv(1024).decode())
    if file_size != -1:
        content = client.recv(file_size).decode()
        with open(file_path + "-copy", 'w') as file:
            file.write(content)
    else:
        print("File does not exist.")
    client.close()
    print("Connection closed.")

if __name__ == "__main__":
    main()