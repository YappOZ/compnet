#6.   The server chooses a random integer number. Each client generates a random integer number and send it to the server. 
# The server answers with the message “larger” if the client has sent a smaller number than the server’s choice, or with message “smaller” if the client has send a larger number than the server’s choice. 
# Each client continues generating a different random number (larger or smaller than the previous) according to the server’s indication. When a client guesses the server choice – 
# the server sends back to the winner the message “You win – within x tries”. It also sends back to all other clients the message “You lost – after y retries!” (x and y are the number of tries of each respective client). 
# The server closes all connections upon a win and it chooses a different random integer for the next game (set of clients) - threads/processes
#client

import socket
import pickle
import time
import random

host = '192.168.1.8'
port = 12345

def main():
    max_guess = 100
    min_guess = 1
    guess = random.randint(1, 100)
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((host, port))
        while True:
            time.sleep(1)
            client.send(pickle.dumps(guess))
            response_data = client.recv(1024)
            if not response_data:
                print('Server closed the connection.')
                break
            response = pickle.loads(response_data)
            print(response)
            #random number larger or smaller than previous
            if 'larger' in response:
                min_guess = guess
                guess = random.randint(guess + 1, max_guess)
            elif 'smaller' in response:
                max_guess = guess
                guess = random.randint(min_guess, max_guess - 1)
            if 'win' in response or 'lost' in response:
                break
    except Exception as e:
        print('An error occurred:', e)
    finally:
        client.close()
        print('Connection closed.')

if __name__ == '__main__':
    main()