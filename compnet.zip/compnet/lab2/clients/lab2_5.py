#5.   The client sends a domain name taken from the command line (Ex: www.google.com) to the server. 
# The server opens a TCP connection to the IP address corresponding to the received domain name on port 80 (called HTTP-Srv). 
# It sends on the TCP connection the string: “GET / HTTP/1.0\n\n” and relays the answer back to the client. 
# When HTTP-Srv closes connection to the server, the server closes the connection to the client at its turn. threads/processes
#client

import socket
import sys
import pickle

host = '192.168.1.8'
port = 12345

def main():
    if len(sys.argv) != 2:
            print("Usage: python client.py <domain>")
            return
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((host, port))
        client.settimeout(10)
            
        domain = sys.argv[1]
        client.send(pickle.dumps(domain))
        
        # Receive and print response
        try:
            while True:
                response = client.recv(4096)
                if not response:
                    break
                print(response.decode(errors='ignore'))
        except socket.timeout:
            print("Response complete or timed out")
            
    except Exception as e:
        print("An error occurred:", e)
    finally:
        client.close()
        print("Connection closed.")

if __name__ == "__main__":
    main()