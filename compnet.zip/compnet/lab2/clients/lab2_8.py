#8.   Build a server that facilitates a peer-to-peer (P2P) file-sharing network. 
# The server maintains a directory of files and connected peers. 
# Clients can request files, and the server connects them to peers that have the requested files. 
# Data transfers happens over TCP. -threads/processes

#---------------------CLIENT---------------------
import socket
import pickle
import sys
import threading
import time

class FileClient:
    def __init__(self, server_ip='192.168.1.8', server_port=12345, client_port=0):
        self.server_ip = server_ip
        self.server_port = server_port
        self.client_port = client_port
        self.active_peers = set()
        self.lock = threading.Lock()
        self.socket = None
        self.running = True
        self.local_address = None
    
    def setup_socket(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind(('', self.client_port))
        self.local_address = (self.server_ip, self.client_port)
        return self.socket
    
    def update_peers(self, new_peers):
        """Update the peer list and print only if there are changes"""
        with self.lock:
            old_peers = self.active_peers.copy()
            # Filter out our own address from the peer list
            self.active_peers = {peer for peer in new_peers if peer[1] != self.client_port}
            if old_peers != self.active_peers:
                print("\nPeer list updated:")
                print("Active peers:", self.active_peers)

    def listen_for_updates(self):
        """Listens for updates from the server and updates the active_peers set."""
        while self.running:
            try:
                data, addr = self.socket.recvfrom(1024)
                if addr == (self.server_ip, self.server_port):
                    try:
                        peers = pickle.loads(data)
                        self.update_peers(peers)
                    except Exception as e:
                        print(f"Error processing peer update: {e}")
            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    print(f"Update listener error: {e}")
                    
    def request_file(self, filename):
        """Request a file from the server."""
        try:
            data = pickle.dumps(("REQUEST", filename))
            self.socket.sendto(data, (self.server_ip, self.server_port))
        except Exception as e:
            print(f"Error requesting file: {e}")
            
    def receive_file(self, filename):
        """Receive a file from a peer."""
        try:
            data, addr = self.socket.recvfrom(1024)
            peer_addr = pickle.loads(data)
            if peer_addr:
                print(f"File found at {peer_addr}. Downloading...")
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.connect(peer_addr)
                    s.sendall(pickle.dumps(filename))
                    with open(filename, 'wb') as f:
                        while True:
                            data = s.recv(1024)
                            if not data:
                                break
                            f.write(data)
                print(f"File {filename} downloaded successfully.")
            else:
                print(f"File {filename} not found.")
        except Exception as e:
            print(f"Error receiving file: {e}")
            
    def run(self):
        try:
            self.setup_socket()
            print(f"Client listening on {self.local_address}")
            
            # Listen for updates from the server
            update_thread = threading.Thread(target=self.listen_for_updates)
            update_thread.start()
            
            while self.running:
                try:
                    command = input("Enter command: ")
                    if command.lower() == "exit":
                        self.running = False
                        break
                    elif command.startswith("request"):
                        _, filename = command.split(' ', 1)
                        self.request_file(filename)
                    elif command.startswith("receive"):
                        _, filename = command.split(' ', 1)
                        self.receive_file(filename)
                except Exception as e:
                    print(f"Error processing command: {e}")
        except KeyboardInterrupt:
            print("\nClient shutting down gracefully...")
        finally:
            if self.socket:
                self.socket.close()
                
def main():
    client = FileClient()
    client.run()
    
if __name__ == "__main__":
    main()