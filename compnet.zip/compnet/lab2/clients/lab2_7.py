#7.   The client reads a username and a password from the standard input. It sends the username to the server. 
# The server uses the getpwent system call repeatedly to find the password information about the username. 
# If the entry for the username is found, the password field from the struct passwd is returned to the client. 
# The client recovers the salt of the password and checks the input password with the received encrypted version using the crypt system call. 
# If there is no user username, the server returns back to the client the empty string and closes the connection. -threads/processes
# client

import socket
import threading
import crypt
import pwd
import os

host = '192.168.1.8'
port = 12345

def main():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))
    
    try:
        while True:
            username = input('Enter username: ')
            if not username:
                break
            client_socket.send(username.encode())
            salt = client_socket.recv(1024).decode()
            if not salt:
                break
            password = input('Enter password: ')
            client_socket.send(crypt.crypt(password, salt).encode())
            response = client_socket.recv(1024).decode()
            print(response)
    except Exception as e:
        print('An error occurred with the client:', e)
    finally:
        client_socket.close()
    
if __name__ == '__main__':
    main()