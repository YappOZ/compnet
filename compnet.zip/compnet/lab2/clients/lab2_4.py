#4.   The clients send an integer number N and an array of N float values. 
# The server will merge sort the numbers received from all clients until it gets an empty array of floats (N=0). 
# The server returns to each client the size of the merge-sorted array followed by the merge-sorted arrays of all floats from all clients. -threads/processes
#client

import socket
import random
import pickle

host = '192.168.1.8'
port = 12345

def main():
    float_array = []
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect((host, port))
        n = int(input("Enter the number of floats: "))
        float_array = [random.uniform(0, 100) for _ in range(n)]
        print("Generated floats:", float_array)
        client.send(pickle.dumps((n, float_array)))
        
        # Wait for the server's response without closing the connection prematurely
        print("Waiting for the server's response...")
        length, new_array = pickle.loads(client.recv(1024))
        print("Length of merge-sorted array:", length)
        print("Merge-sorted array:", new_array)
    except Exception as e:
        print("An error occurred:", e)
    finally:
        client.close()
        print("Connection closed.")
        

if __name__ == "__main__":
    main()