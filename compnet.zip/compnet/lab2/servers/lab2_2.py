#
# 2.   The client sends the complete path to a file. The server returns back the length of the file and its content in the case the file exists.
# When the file does not exist the server returns a length of -1 and no content. 
# The client will store the content in a file with the same name as the input file with the suffix –copy appended (ex: for f.txt => f.txt-copy). -threads/processes
#server needs to be concurrent – i.e. be able to accept multiple clients at the same time.

import socket
import os
import threading

host = '192.168.1.8'
port = 12345

def client_handler(client_socket, address):
    print("Accepted connection from: ", address)
    file_path = client_socket.recv(1024).decode()
    print("Received file path: ", file_path)
    if os.path.isfile(file_path):
        file_size = os.path.getsize(file_path)
        client_socket.send(str(file_size).encode())
        with open(file_path, 'r') as file:
            content = file.read()
            client_socket.send(content.encode())
    else:
        client_socket.send("-1".encode())
    client_socket.close()
    print("Connection closed with: ", address)

def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((host, port))
    server.listen(5)
    print("Server listening on port: ", port)
    while True:
        client, address = server.accept()
        client_thread = threading.Thread(target=client_handler, args=(client, address), daemon=True)
        client_thread.start()

if __name__ == "__main__":
    main()