#4.   The clients send an integer number N and an array of N float values. 
# The server will merge sort the numbers received from all clients until it gets an empty array of floats (N=0). 
# The server returns to each client the size of the merge-sorted array followed by the merge-sorted arrays of all floats from all clients. -threads/processes
#server needs to be concurrent – i.e. be able to accept multiple clients at the same time.

import socket
import threading
import pickle

host = '192.168.1.8'
port = 12345
clients = []
clients_data = []
float_array = []

lock = threading.Lock()
exit_signal_received = threading.Event()

def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    
    return merge(left, right)

def merge(left, right):
    result = []
    i = j = 0
    
    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    
    result.extend(left[i:])
    result.extend(right[j:])
    
    return result

def client_handler(client_socket):
    print("Accepted connection")
    try:
        data = pickle.loads(client_socket.recv(1024))
        with lock:
            clients.append(client_socket)
            if data[0] == 0:  # Check if the array is empty
                exit_signal_received.set()  # Signal that no more clients should be accepted
            else:
                clients_data.append(data[1])
        print("Received data: {}".format(data[1]))
    except Exception as e:
        print("Error receiving data from client: {}".format(e))
        client_socket.close()

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print("Server listening on port: ", port)
    
    try:
        while not exit_signal_received.is_set():
            s.settimeout(1.0)  # Allow periodic checks for the exit signal
            try:
                client, addr = s.accept()
                client_thread = threading.Thread(target=client_handler, args=(client,))
                client_thread.start()
            except socket.timeout:
                continue
        
        # Merge sort the float arrays
        with lock:
            for data in clients_data:
                float_array.extend(data)
        
        sorted_array = merge_sort(float_array)
        
        # Notify all clients
        for client in clients:
            try:
                client.send(pickle.dumps((len(sorted_array), sorted_array)))
            except Exception as e:
                print("Error sending data to client: {}".format(e))
            finally:
                client.close()
    except KeyboardInterrupt:
        print("Server interrupted by user")
    finally:
        s.close()
        print("Server closed all connections.")

if __name__ == "__main__":
    main()
