#1.   The client takes a string from the command line and sends it to the server. 
# The server interprets the string as a command with its parameters. 
# It executes the command and returns the standard output and the exit code to the client. -threads/processes
#server

import socket
import subprocess
import os
import sys
import threading
import signal

def signal_handler(sig, frame):
    print('Signal handler called with signal', sig)
    sys.exit(0)

def handle_client(client_socket):
    try:
        while True:
            data = client_socket.recv(4096).decode('utf-8')
            if not data:
                break

            print('Received:', data)
            args = data.split(' ')

            if args[0] == 'exit':
                print("Client requested exit.")
                break
            elif args[0] == 'cd':
                try:
                    os.chdir(args[1])
                    response = f'Changed directory to {args[1]}\n'
                except (FileNotFoundError, IndexError):
                    response = 'Directory not found or invalid command\n'
                client_socket.send(response.encode('utf-8'))
            else:
                try:
                    output = subprocess.check_output(args, stderr=subprocess.STDOUT, text=True)
                    client_socket.send(output.encode('utf-8'))
                except subprocess.CalledProcessError as e:
                    error_message = f"Command failed with exit code {e.returncode}: {e.output}"
                    client_socket.send(error_message.encode('utf-8'))
                except FileNotFoundError:
                    client_socket.send(b'Command not found\n')
    finally:
        client_socket.close()

def main():
    signal.signal(signal.SIGINT, signal_handler)
    host = input('Enter server IP to bind (default 192.168.1.8): ') or '192.168.1.8'
    port = int(input('Enter port (default 12345): ') or 12345)
    
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((host, port))
    server.listen(5)
    print(f'Listening on {host}:{port}')

    while True:
        client, addr = server.accept()
        print(f'Accepted connection from {addr[0]}:{addr[1]}')
        client_handler = threading.Thread(target=handle_client, args=(client,))
        client_handler.start()

if __name__ == '__main__':
    main()
