#3.   The server chooses a random float number <SRF>. Run multiple clients. Each client chooses a random float number <CRF> and send it to the server. 
#  When the server does not receive any incoming connection for at least 10 seconds 
# it chooses the client that has guessed the best approximation (is closest) for its own number and sends it 
# back the message “You have the best guess with an error of <SRV>-<CRF>”. 
# It also sends to each other client the string “You lost !”. The server closes all connections after this. -threads/processes
#server needs to be concurrent – i.e. be able to accept multiple clients at the same time.

import socket
import threading
import random
import time
import pickle

host = '192.168.1.8'
port = 12345
server_random_float = random.uniform(0, 100)
clients = []
clients_guesses = {}

lock = threading.Lock()

def client_handler(client_socket):
    print("Accepted connection")
    try:
        client_guess = pickle.loads(client_socket.recv(1024))
        with lock:
            clients.append(client_socket)
            clients_guesses[client_socket] = client_guess
        print("Received guess: {}".format(client_guess))
    except Exception as e:
        print("Error receiving data from client: {}".format(e))

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print("Server listening on port:", port)
    print("Server random float:", server_random_float)
    while True:
        s.settimeout(1)
        try:
            client, addr = s.accept()
            last_connection_time = time.time()
            client_thread = threading.Thread(target=client_handler, args=(client,))
            client_thread.start()
        except socket.timeout:
            # Check if no new connections were received for 10 seconds
            if time.time() - last_connection_time >= 10 and clients_guesses:
                break

    # Find the client with the closest guess
    closest_client = min(clients_guesses, key=lambda c: abs(server_random_float - clients_guesses[c]))

    # Notify all clients
    for client in clients:
        try:
            if client == closest_client:
                error = abs(server_random_float - clients_guesses[client])
                message = "You have the best guess with an error of {:.2f}".format(error)
            else:
                message = "You lost !"
            
            client.send(message.encode())
        except Exception as e:
            print("Error sending message to client: {}".format(e))
        finally:
            client.close()

    s.close()
    print("Server closed all connections.")

if __name__ == "__main__":
    main()
