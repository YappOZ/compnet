#5.   The client sends a domain name taken from the command line (Ex: www.google.com) to the server. 
# The server opens a TCP connection to the IP address corresponding to the received domain name on port 80 (called HTTP-Srv). 
# It sends on the TCP connection the string: “GET / HTTP/1.0\n\n” and relays the answer back to the client. 
# When HTTP-Srv closes connection to the server, the server closes the connection to the client at its turn. threads/processes
#server needs to be concurrent – i.e. be able to accept multiple clients at the same time.

import socket
import threading
import sys
import pickle

host = '192.168.1.8'
port = 12345

def client_handler(client_socket, address):
    print('Accepted connection from:', address)
    
    try:
        # Receive and unpickle the domain name
        domain = pickle.loads(client_socket.recv(1024))
        print('Received domain:', domain)
        
        ip = socket.gethostbyname(domain)
        print('IP address:', ip)
        
        # Connect to the target website
        http_srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        http_srv.settimeout(10)
        http_srv.connect((ip, 80))
        
        # Send HTTP request
        request = "GET / HTTP/1.0\r\nHost: {}\r\n\r\n".format(domain)
        http_srv.send(request.encode())
        
        # Forward the first chunk of response to client
        response = http_srv.recv(4096)
        if response:
            client_socket.send(response)
    except Exception as e:
        print('An error occurred:', str(e))
    finally:
        try:
            http_srv.close()
        except:
            pass
        client_socket.close()
        print('Connection closed with:', address)

def main():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((host, port))
    server.listen(5)
    print('Server listening on port:', port)
    
    try:
        while True:
            client, address = server.accept()
            client_thread = threading.Thread(
                target=client_handler, 
                args=(client, address),
                daemon=True
            )
            client_thread.start()
    except KeyboardInterrupt:
        print("\nShutting down server...")
    finally:
        server.close()

if __name__ == '__main__':
    main()