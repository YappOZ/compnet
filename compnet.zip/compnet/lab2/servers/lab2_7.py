#7.   The client reads a username and a password from the standard input. It sends the username to the server. 
# The server uses the getpwent system call repeatedly to find the password information about the username. 
# If the entry for the username is found, the password field from the struct passwd is returned to the client. 
# The client recovers the salt of the password and checks the input password with the received encrypted version using the crypt system call. 
# If there is no user username, the server returns back to the client the empty string and closes the connection. -threads/processes
# server needs to be able to handle multiple clients at the same time

import socket
import threading
import crypt
import pwd
import os

host = '192.168.1.8'
port = 12345
lock = threading.Lock()

def client_handler(client_socket, address):
    print('Accepted connection from:', address)
    try:
        while True:
            username = client_socket.recv(1024).decode()
            if not username:
                break
            try:
                user_info = pwd.getpwnam(username)
                password = user_info.pw_passwd
                salt = password[:2]
                client_socket.send(salt.encode())
                client_password = client_socket.recv(1024).decode()
                if crypt.crypt(client_password, salt) == password:
                    client_socket.send('Correct password'.encode())
                else:
                    client_socket.send('Incorrect password'.encode())
            except KeyError:
                client_socket.send('No such user'.encode())
                break
    except Exception as e:
        print('An error occurred with client {}: {}'.format(address, e))
    finally:
        client_socket.close()
        print('Connection closed with:', address)

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(5)
    print('Server listening on port:', port)
    
    try:
        while True:
            client_socket, addr = server_socket.accept()
            client_thread = threading.Thread(target=client_handler, args=(client_socket, addr))
            client_thread.start()
    except Exception as e:
        print('An error occurred with the server:', e)
    finally:
        server_socket.close()

if __name__ == '__main__':
    main()