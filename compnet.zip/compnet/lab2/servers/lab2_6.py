#6.   The server chooses a random integer number. Each client generates a random integer number and send it to the server. 
# The server answers with the message “larger” if the client has sent a smaller number than the server’s choice, or with message “smaller” if the client has send a larger number than the server’s choice. 
# Each client continues generating a different random number (larger or smaller than the previous) according to the server’s indication. When a client guesses the server choice – 
# the server sends back to the winner the message “You win – within x tries”. It also sends back to all other clients the message “You lost – after y retries!” (x and y are the number of tries of each respective client). 
# The server closes all connections upon a win and it chooses a different random integer for the next game (set of clients) - threads/processes
#server 

import socket
import threading
import random
import pickle

host = '192.168.1.8'
port = 12345
client_tries = {}
server_choice = random.randint(1, 100)
found_winner = False
lock = threading.Lock()

def client_handler(client_socket, address):
    print('Accepted connection from:', address)
    global found_winner
    try:
        while True:
            data = client_socket.recv(1024)
            if not data:
                break
            guess = pickle.loads(data)
            with lock:
                client_tries[client_socket] += 1
                if found_winner:
                    client_socket.send(pickle.dumps('You lost - after {} tries'.format(client_tries[client_socket])))
                    break  # Break the loop to close the connection
                else:
                    if guess == server_choice:
                        found_winner = True
                        client_socket.send(pickle.dumps('You win - within {} tries'.format(client_tries[client_socket])))
                        break
                    elif guess < server_choice:
                        client_socket.send(pickle.dumps('larger'))
                    else:
                        client_socket.send(pickle.dumps('smaller'))
    except Exception as e:
        print('An error occurred with client {}: {}'.format(address, e))
    finally:
        client_socket.close()
        print('Connection closed with:', address)

def main():
    global found_winner, server_choice, client_list, client_tries
    print('Server choice:', server_choice)
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((host, port))
    server_socket.listen(5)
    print('Server listening on port:', port)
    
    try:
        while True:
            client_socket, addr = server_socket.accept()
            with lock:
                client_tries[client_socket] = 0
            client_thread = threading.Thread(
                target=client_handler,
                args=(client_socket, addr),
                daemon=True
            )
            client_thread.start()
            with lock:
                if found_winner:
                    found_winner = False
                    server_choice = random.randint(1, 100)
                    client_tries.clear()
                    print('Server choice:', server_choice)
    except Exception as e:
        print('An error occurred:', e)
    finally:
        server_socket.close()
        print('Server closed')


if __name__ == "__main__":
    main()