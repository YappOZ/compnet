#2.   A client sends to the server a string. The server returns the count of spaces in the string. -tcp
##client

import socket
import pickle

host = '192.168.1.8'
port = 12345

def main():
    string = 'Hello, world!'
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    s.sendall(pickle.dumps(string))
    data = s.recv(1024)
    result = data.decode()
    print('Count of spaces:', result)
    s.close()

if __name__ == '__main__':
    main()