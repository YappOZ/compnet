#5.   The client sends to the server an integer. The server returns the list of divisors for the specified number. -tcp
#client

import socket
import pickle

host = '192.168.1.8'
port = 12345

def main():
    number = 10
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    s.sendall(pickle.dumps(number))
    data = s.recv(1024)
    result = pickle.loads(data)
    print('Divisors:', result)
    s.close()

if __name__ == '__main__':
    main()