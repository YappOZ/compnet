#6.   The client sends to the server a string and a character. The server returns to the client a list of all positions in the string where specified character is found. -tcp
#client

import socket
import pickle

host = '192.168.1.8'
port = 12345

def main():
    string = 'Hello, world!'
    char = 'o'
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    s.sendall(pickle.dumps((string, char)))
    data = s.recv(1024)
    result = pickle.loads(data)
    print('Positions:', result)
    s.close()

if __name__ == '__main__':
    main()