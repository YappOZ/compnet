#11.Define a simple structure (e.g., a Person object with firstname, lastname, gender  and age). 
# The client sends this structure to the server. The server increments the age and sends the updated structure back. -tcp
#client

import socket
import pickle

host = '192.168.1.8'
port = 12345

class Person:
    def __init__(self, firstname, lastname, age):
        self.firstname = firstname
        self.lastname = lastname
        self.age = age
    
    def __str__(self):
        return f'{self.firstname} {self.lastname} {self.age}'
    
    def increment_age(self):
        self.age += 1

def main():
    person = Person('John', 'Doe', 30)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.connect((host, port))
        print('Connected to server')
        s.sendall(pickle.dumps(person))
    except Exception as e:
        print(f"Error sending data: {e}")
    data = s.recv(4096)
    person = pickle.loads(data)
    print('Updated person:', person)
    s.close()

if __name__ == '__main__':
    main()