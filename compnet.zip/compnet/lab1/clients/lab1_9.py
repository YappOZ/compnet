#9.   The client sends to the server two arrays of numbers. The server returns to the client a list of numbers that are present in the first arrays but not in the second. -tcp
#client

import socket
import pickle

host = '192.168.1.8'
port = 12345

def main():
    array1 = [1, 2, 3, 4, 5]
    array2 = [3, 4, 5, 6, 7]
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    s.sendall(pickle.dumps((array1, array2)))
    data = s.recv(1024)
    result = pickle.loads(data)
    print('Numbers in first array but not in second:', result)
    s.close()

if __name__ == '__main__':
    main()