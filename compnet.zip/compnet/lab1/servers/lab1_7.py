#7.   The client sends to the server a string and two numbers (s, I, l). The sever returns to the client the substring of s starting at index I, of length l. -tcp
#server

import socket
import pickle

host = '192.168.1.8'
port = 12345

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print('Server is listening...')
    conn, addr = s.accept()
    print('Connection from:', addr)
    data = conn.recv(1024)
    string, i, l = pickle.loads(data)
    result = string[i:i+l]
    conn.sendall(pickle.dumps(result))
    conn.close()
    print('Connection closed')

if __name__ == '__main__':
    main()