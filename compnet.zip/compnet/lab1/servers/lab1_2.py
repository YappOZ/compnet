#2.   A client sends to the server a string. The server returns the count of spaces in the string. -tcp
##server

import socket
import pickle

host = '192.168.1.8'
port = 12345

def count_spaces(s):
    return s.count(' ')

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print('Server is listening...')
    while True:
        conn, addr = s.accept()
        print('Connected to', addr)
        data = conn.recv(1024)
        string = pickle.loads(data)
        print('Received:', string)
        result = count_spaces(string)
        conn.sendall(str(result).encode())
        conn.close()
        print('Connection closed')
        break
    s.close()
    print('Server closed')

if __name__ == '__main__':
    main()