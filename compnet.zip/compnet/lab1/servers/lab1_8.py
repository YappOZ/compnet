#8.   The client sends to the server two arrays of integers. The server returns an arrays containing the common numbers found in both arrays. -tcp
#server

import socket
import pickle

host = '192.168.1.8'
port = 12345

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print('Server is listening...')
    conn, addr = s.accept()
    print('Connection address:', addr)
    data = conn.recv(1024)
    arrays = pickle.loads(data)
    result = list(set(arrays[0]) & set(arrays[1]))
    conn.sendall(pickle.dumps(result))
    conn.close()
    s.close()
    print('Connection closed')

if __name__ == '__main__':
    main()