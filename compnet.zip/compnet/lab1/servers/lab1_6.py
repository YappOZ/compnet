#6.   The client sends to the server a string and a character. The server returns to the client a list of all positions in the string where specified character is found. -tcp
#server

import socket
import pickle

host = '192.168.1.8'
port = 12345

def find_char(s, c):
    return [i for i, char in enumerate(s) if char == c]

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print('Server is listening...')
    while True:
        conn, addr = s.accept()
        print('Connected to', addr)
        data = conn.recv(1024)
        string, char = pickle.loads(data)
        print('Received:', string, char)
        result = find_char(string, char)
        conn.sendall(pickle.dumps(result))
        conn.close()
        print('Connection closed')
        break

if __name__ == '__main__':
    main()