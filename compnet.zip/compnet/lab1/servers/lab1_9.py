#9.   The client sends to the server two arrays of numbers. The server returns to the client a list of numbers that are present in the first arrays but not in the second. -tcp
#server

import socket
import pickle

host = '192.168.1.8'
port = 12345

def get_diff(arrays):
    new_list = []
    for i in arrays[0]:
        if i not in arrays[1]:
            new_list.append(i)
    return new_list

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print('Server is listnening... ')
    conn, addr = s.accept()
    print('Connection address: ', addr)
    data = conn.recv(1024)
    arrays = pickle.loads(data)
    result = get_diff(arrays)
    conn.sendall(pickle.dumps(result))
    conn.close()
    s.close()
    print('Connection closed')

if __name__ == '__main__':
    main()