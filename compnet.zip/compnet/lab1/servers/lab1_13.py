#13.The client sends a small text file to the server. The server saves the file and returns the length of the received file content as an unsigned integer -tcp
#server

import socket
import pickle

host = '192.168.1.8'
port = 12345

def main():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((host, port))
    s.listen(5)
    print('Server is listening...')
    conn, addr = s.accept()
    print('Connection address: ', addr)
    data = conn.recv(1024)
    with open('received_file.txt', 'wb') as f:
        f.write(pickle.loads(data))
        conn.sendall(pickle.dumps(len(pickle.loads(data))))
    conn.close()
    s.close()
    print('Connection closed')

if __name__ == '__main__':
    main()