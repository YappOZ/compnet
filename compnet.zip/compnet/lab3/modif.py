import socket
import time
import threading
import sys
import datetime
import queue
import os
import platform
import logging
import uuid

# Global variables
BROADCAST_ADDRESS = ""
PORT = 7777
TIMEQUERY = "TIMEQUERY\0"
DATEQUERY = "DATEQUERY\0"
TIME_FORMAT = "%H:%M:%S"
DATE_FORMAT = "%d:%m:%Y"

# Peer tracking and message queues
peers = {}
client_uuids = {}
malformed = queue.Queue(10)
running = True
lock = threading.Lock()
response_queue = queue.Queue()

# Logging configuration
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


def generate_client_uuid():
    return str(uuid.uuid4())

def get_broadcast_address():
    global BROADCAST_ADDRESS
    if len(sys.argv) != 2:
        print("Usage: python modif.py <broadcast_address>")
        sys.exit(1)
    BROADCAST_ADDRESS = sys.argv[1]

def get_time():
    return datetime.datetime.now().strftime(TIME_FORMAT)

def get_date():
    return datetime.datetime.now().strftime(DATE_FORMAT)

def display_status():
    os.system('cls' if platform.system() == 'Windows' else 'clear')
    with lock:
        print("Peers:")
        if peers:
            for peer, data in peers.items():
                print(f"{peer} TIME {data['time']} DATE {data['date']}")
        else:
            print("No peers found.")
        print("\nMalformed Data:")
        while not malformed.empty():
            print(malformed.get())
    print("\n")

def add_malformed(ip, data=None):
    with lock:
        if malformed.qsize() == 10:
            malformed.get()  # Remove the oldest malformed message
        malformed.put(f"{ip} - {data if data else 'Malformed message'}")


def manage_peers():
    while running:
        with lock:
            # Increment each peer's count and remove if no response
            for peer in list(peers):
                peers[peer]["count"] += 1
                if peers[peer]["count"] >= 3:
                    del peers[peer]
        time.sleep(3)  # Checks peer status every 3 seconds

import random

def send_query(query, interval):
    while running:
        time.sleep(random.uniform(0, interval))
        sock.sendto(query.encode(), (BROADCAST_ADDRESS, PORT))
        logger.info(f"Sent {query.strip()} broadcast")
        time.sleep(interval)

def handle_responses():
    while running:
        try:
            data, addr = sock.recvfrom(1024)
            msg = data.decode().strip().replace('\0', '')  # Clean message of any null terminators and whitespace
            addr_str = f"{addr[0]}:{addr[1]}"
            
            client_uuid = client_uuids.get(addr_str, None)
            if client_uuid is None:
                client_uuid = generate_client_uuid()
                client_uuids[addr_str] = client_uuid
            
            logger.info(f"Received data from {addr_str}: {msg}")

            with lock:
                process_message(msg, addr_str, addr, client_uuid)

        except Exception as e:
            logger.error(f"Error receiving data: {e}")


def process_message(msg, addr_str, addr, client_uuid):
    # Recognize TIMEQUERY and DATEQUERY as requests
    if msg == "TIMEQUERY":
        response = f"TIME {get_time()} UUID {client_uuid}"
        response_queue.put((addr, response))
        logger.info(f"Responding with time to {addr_str}")
        if addr_str not in peers:
            peers[addr_str] = {"time": get_time(), "date": get_date(), "count": 0, "uuid": client_uuid}
        else:
            peers[addr_str].update({"time": get_time(), "date": get_date(), "count": 0, "uuid": client_uuid})
    
    elif msg == "DATEQUERY":
        response = f"DATE {get_date()} UUID {client_uuid}"
        response_queue.put((addr, response))
        logger.info(f"Responding with date to {addr_str}")
        if addr_str not in peers:
            peers[addr_str] = {"time": get_time(), "date": get_date(), "count": 0, "uuid": client_uuid}
        else:
            peers[addr_str].update({"time": get_time(), "date": get_date(), "count": 0, "uuid": client_uuid})
    
    # Recognize TIME and DATE as responses and store them without treating them as malformed
    elif msg.startswith("TIME"):
        parts = msg.split(" ")
        time_data = parts[1] if len(parts) > 1 else get_time()
        uuid_data = parts[3] if len(parts) > 3 else client_uuid
        peers[addr_str] = {"time": time_data, "date": peers.get(addr_str, {}).get("date", get_date()), "count": 0, "uuid": uuid_data}
        logger.info(f"Updated peer {addr_str} with time: {time_data} and UUID: {uuid_data}")
    
    elif msg.startswith("DATE"):
        parts = msg.split(" ")
        date_data = parts[1] if len(parts) > 1 else get_date()
        uuid_data = parts[3] if len(parts) > 3 else client_uuid
        peers[addr_str] = {"time": peers.get(addr_str, {}).get("time", get_time()), "date": date_data, "count": 0, "uuid": uuid_data}
        logger.info(f"Updated peer {addr_str} with date: {date_data} and UUID: {uuid_data}")

    # Treat any other message as malformed
    else:
        add_malformed(addr_str, msg)
        logger.warning(f"Malformed message from {addr_str}: {msg}")


def send_responses():
    while running:
        if not response_queue.empty():
            addr, response = response_queue.get()
            sock.sendto(response.encode(), addr)
            logger.info(f"Sent response to {addr}: {response}")

def update_display():
    while running:
        display_status()
        time.sleep(3)  # Refresh display every 3 seconds

def main():
    global running
    global sock

    get_broadcast_address()
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)  # Enable loopback for testing
    sock.bind(("", PORT))

    # Starting threads for time, date, response handling, peer checking, and display
    threads = [
        threading.Thread(target=send_query, args=(TIMEQUERY, 3)),
        threading.Thread(target=send_query, args=(DATEQUERY, 10)),
        threading.Thread(target=handle_responses),
        threading.Thread(target=manage_peers),
        threading.Thread(target=send_responses),
        threading.Thread(target=update_display)
    ]

    for t in threads:
        t.start()

    try:
        for t in threads:
            t.join()
    except KeyboardInterrupt:
        running = False
        for t in threads:
            t.join()

if __name__ == "__main__":
    main()
