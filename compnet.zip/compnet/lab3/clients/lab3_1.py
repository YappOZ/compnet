#1.   The client sends periodical PING datagrams with a random content to a <server> and <port> specified in command line. 
# The server returns back (echoes) the same packets (content). The client checks the content of the received packets to match 
# what was sent and computes the round trip time and displays it to the user – for each sent packet. -concurrent UDP servers

# 
# client implementation

import socket
import time
import random
import sys

def main():
    if len(sys.argv) != 3:
        print("Usage: python lab3_client.py <server_ip> <server_port>")
        sys.exit(1)

    server_ip = sys.argv[1]
    server_port = int(sys.argv[2])

    # Create UDP client socket
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    try:
        while True:
            # Generate random message
            message = str(random.randint(1, 1000)).encode('utf-8')
            
            # Record send time
            start_time = time.time()
            client_socket.sendto(message, (server_ip, server_port))

            # Receive server response
            data, _ = client_socket.recvfrom(1024)
            end_time = time.time()

            # Compute RTT
            rtt = end_time - start_time
            print(f"Sent: {message.decode('utf-8')} | RTT: {rtt:.6f} seconds")

            # Validate echoed message
            if message != data:
                print("Error: Data mismatch!")
                break

            time.sleep(1)
    except KeyboardInterrupt:
        print("\nClient terminated.")
    finally:
        client_socket.close()

if __name__ == "__main__":
    main()
