import socket
import random
import pickle
import time

host = '192.168.1.8'
port = 12345

# Server state
client_tries = {}
server_choice = random.randint(1, 100)
found_winner = False

def main():
    global found_winner, server_choice, client_tries
    print('Server choice:', server_choice)
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind((host, port))
    print('Server listening on port:', port)
    
    try:
        while True:
            try:
                # Receive data and address from the client
                data, address = server_socket.recvfrom(1024)
                if not data:
                    continue
                guess = pickle.loads(data)
                
                # Initialize client tries if not already
                if address not in client_tries:
                    client_tries[address] = 0

                client_tries[address] += 1

                if found_winner:
                    # Inform all clients that the game is over
                    server_socket.sendto(
                        pickle.dumps('Game over! You lost - Winner was found after {} tries'.format(client_tries[address])),
                        address
                    )
                    continue

                if guess == server_choice:
                    found_winner = True
                    server_socket.sendto(
                        pickle.dumps('You win! It took you {} tries.'.format(client_tries[address])),
                        address
                    )
                    print(f"Winner found: {address}")
                    continue

                if guess < server_choice:
                    server_socket.sendto(pickle.dumps('larger'), address)
                else:
                    server_socket.sendto(pickle.dumps('smaller'), address)

            except socket.timeout:
                # Timeout is expected and does not need logging
                pass
            except Exception as e:
                print('Error:', e)
            
            # Reset game state if a winner was found
            if found_winner:
                time.sleep(5)
                found_winner = False
                server_choice = random.randint(1, 100)
                print('New server choice:', server_choice)
                client_tries.clear()
    except Exception as e:
        print('Server error:', e)
    finally:
        server_socket.close()
        print('Server closed')

if __name__ == "__main__":
    main()
