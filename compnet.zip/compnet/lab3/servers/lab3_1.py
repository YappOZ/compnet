#1.   The client sends periodical PING datagrams with a random content to a <server> and <port> specified in command line. 
# The server returns back (echoes) the same packets (content). The client checks the content of the received packets to match 
# what was sent and computes the round trip time and displays it to the user – for each sent packet. -concurrent UDP servers
#server
import socket
import threading

ip = '192.168.1.8'  # Server IP
port = 12345        # Server Port

def main():
    # Create a UDP socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind((ip, port))
    server_socket.settimeout(1.0)  
    print(f"Server listening on {ip}:{port}")

    try:
        while True:
            try:
                # Attempt to receive data (non-blocking due to timeout)
                data, addr = server_socket.recvfrom(1024)
                # Handle each client in a separate thread
                print(f"Received data from {addr}: {data.decode('utf-8')}")
                # Echo the data back to the client
                server_socket.sendto(data, addr)
            except socket.timeout:
                # Timeout expired, continue loop to check for Ctrl+C
                continue
            except Exception as e:
                print(f"Error handling client {addr}: {e}")
    except KeyboardInterrupt:
        print("\nServer shutting down gracefully...")
    finally:
        server_socket.close()

if __name__ == "__main__":
    main()

