import socket

import time

import threading

import sys

import datetime

import queue

import os

import platform

import logging



# Global variables

BROADCAST_ADDRESS = "192.168.1.9"

PORT = 7777

TIMEQUERY = "TIMEQUERY\0"

DATEQUERY = "DATEQUERY\0"

DATE = datetime.datetime.now().strftime("%d:%m:%Y")

TIME = datetime.datetime.now().strftime("%H:%M:%S")

TIME_FORMAT = "%H:%M:%S"

DATE_FORMAT = "%d:%m:%Y"

TIME_RESPONSE_FORMAT = "TIME %H:%M:%S"

DATE_RESPONSE_FORMAT = "DATE %d:%m:%Y"



# Global variables

peers = {}

malformed = queue.Queue(10)

running = True

lock = threading.Lock()



# Logging

logging.basicConfig(level=logging.DEBUG)

logger = logging.getLogger(__name__)

logger.setLevel(logging.DEBUG)



def get_broadcast_address():

    global BROADCAST_ADDRESS

    if len(sys.argv) != 2:

        print("Usage: python server.py <broadcast_address>")

        sys.exit(1)

    BROADCAST_ADDRESS = sys.argv[1]



def get_time():

    return datetime.datetime.now().strftime(TIME_FORMAT)



def get_date():

    return datetime.datetime.now().strftime(DATE_FORMAT)



def get_time_response():

    return datetime.datetime.now().strftime(TIME_RESPONSE_FORMAT)



def get_date_response():

    return datetime.datetime.now().strftime(DATE_RESPONSE_FORMAT)



def display_peers():

    global peers

    global lock

    os.system('cls' if platform.system() == 'Windows' else 'clear')

    lock.acquire()

    for peer in peers:

        print("IP: %s, Date: %s, Time: %s" % (peer, peers[peer][DATE], peers[peer][TIME]))

    lock.release()



def display_malformed():

    global malformed

    if not malformed.empty():

        os.system('cls' if platform.system() == 'Windows' else 'clear')

        while not malformed.empty():

            print(malformed.get())

        print("\n")



def add_malformed(ip, data=None):

    global malformed

    if malformed.qsize() == 10:

        malformed.get()

    if data:

        malformed.put(f"Malformed message from {ip}: {data}")

    else:

        malformed.put(f"Malformed message from {ip}")



def add_peer(ip, date, time):

    global peers

    global lock

    lock.acquire()

    peers[ip] = {"date": date, "time": time, "count": 0}

    lock.release()



def update_peer(ip, date, time):

    global peers

    global lock

    lock.acquire()

    peers[ip]["date"] = date

    peers[ip]["time"] = time

    peers[ip]["count"] = 0

    lock.release()



def remove_peer(ip):

    global peers

    global lock

    lock.acquire()

    del peers[ip]

    lock.release()



def check_peers():

    global peers

    global lock

    global running

    while running:

        lock.acquire()

        for peer in list(peers.keys()):

            if peers[peer]["count"] == 3:

                remove_peer(peer)

            else:

                peers[peer]["count"] += 1

        lock.release()

        time.sleep(3)



def send_time_query():

    global BROADCAST_ADDRESS

    global PORT

    global TIMEQUERY

    global sock

    while running:

        sock.sendto((TIMEQUERY).encode(), (BROADCAST_ADDRESS, PORT))

        logger.info("Sent time query broadcast")

        time.sleep(3)



def send_date_query():

    global BROADCAST_ADDRESS

    global PORT

    global DATEQUERY

    global sock

    while running:

        sock.sendto((DATEQUERY).encode(), (BROADCAST_ADDRESS, PORT))

        logger.info("Sent date query broadcast")

        time.sleep(10)



def handle_responses():

    global peers

    global malformed

    global running

    global lock

    global PORT

    global TIMEQUERY

    global DATEQUERY

    global TIME_RESPONSE

    global DATE_RESPONSE

    global logger



    while running:

        try:

            data, addr = sock.recvfrom(1024)

            logger.info("Received data from %s", str(addr))

            if data.startswith(TIMEQUERY.encode()):

                sock.sendto(get_time_response().encode(), addr)

            elif data.startswith(DATEQUERY.encode()):

                sock.sendto(get_date_response().encode(), addr)

            else:

                try:

                    peer = data.decode().split(" ")[1]

                    if peer in peers:

                        peers[peer]["count"] = 0

                    else:

                        add_peer(peer, get_date(), get_time())

                except (IndexError, ValueError):

                    logger.error("Error parsing peer address from received data: '%s'", data)

                    add_malformed(str(addr), data.decode())

        except Exception as e:

            logger.error("Error: %s", str(e))

            add_malformed(str(addr), str(e))



def main():

    global running

    global BROADCAST_ADDRESS

    global PORT

    global TIMEQUERY

    global DATEQUERY

    global TIME_RESPONSE

    global DATE_RESPONSE

    global logger

    get_broadcast_address()



    global sock

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

    sock.bind(("", PORT))



    t1 = threading.Thread(target=send_time_query)

    t2 = threading.Thread(target=send_date_query)

    t3 = threading.Thread(target=handle_responses)

    t4 = threading.Thread(target=check_peers)



    t1.start()

    t2.start()

    t3.start()

    t4.start()



    t1.join()

    t2.join()

    t3.join()

    t4.join()



if __name__ == "__main__":

    main()