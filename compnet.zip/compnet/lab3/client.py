import socket

BROADCAST_ADDRESS = "192.168.1.9"
PORT = 7777
MESSAGE = "NBCAST 192.168.1.100"

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
sock.sendto(MESSAGE.encode(), (BROADCAST_ADDRESS, PORT))