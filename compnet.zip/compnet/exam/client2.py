"""
Study Buddy Matching System
In a university, students need to find suitable study partners for collaborative learning. To support this need, the university introduces a decentralized system where students can connect to a peer-to-peer network to find study buddies based on their study preferences, subject and time availability. The preferences that a student must mention are: (learning style - one of the characters 'a' - for auditory, 'v' - for visual, 'h' - for hands on; availability - a list of 7 elements that contain, for each day of the week, the time interval during which the student is available for learning: -1 - not available, 1 - in the morning, 2- in the afternoon, 3- in the evening; subject - a string with maximum 32 characters).
The central server only maintains a directory of active students and updates each student when new students enter or exit the network. It does not directly facilitate the matching or communication between students. The central server updates students on new arrivals or departures, helping each student client maintain an updated list of potential study buddies in the network.
Each student connects over TCP to a central server to register for the budding matching system and to receive a list of other students currently in the network. When a student registers it sends to the server its IP address and port that he uses for UDP communication with its peers.
→ Once registered, each student's client application forms a peer-to-peer mesh network over UDP with the other students, allowing them to directly communicate and search for compatible study partners.
◆ Each student shares their preferences with the other students using the UDP connection.
When a student gets some data from another student that has compatible study preferences (same learning style, at least one day of the week in which they can study at the same period, and same subject), he displays the IP and the UDP port and exits the registration system.
Compatible Students Example:
Student A: v,[1, 2, -1, 3, -1, 2, 1], Mathematics
Student B: v, [1, -1, 3, -1, 2, -1, 1], Mathematics
Student A (learning style: v, availability: [1, 2, -1, 3, -1, 2, 1], subject: Mathematics) and Student B (learning style: v, availability: [1, -1, 3, -1, 2, -1, 1], subject: Mathematics) are compatible because they share the same learning style, subject, and have overlapping availability on Monday morning and Sunday morning.
Incompatible Students Example:
Student C: a, [1, -1, 3, 2, -1, -1, 1], Physics
Student D: v, [-1, 2, -1, 3, 1, 2, -1], Physics
Student C (learning style: a, availability: [1, -1, 3, 2, -1, -1, 1], subject: Physics) and Student D (learning style: v, availability: [-1, 2, -1, 3, 1, 2, -1], subject: Physics) are incompatible because their learning styles and availability do not match.
For the grade 5: a client sends to the server over TCP his/her study preferences. The server responds with a greeting message. Check every operation for errors and properly send the data.
"""

#----------------- client.py -----------------
import socket
import json
import threading
import time


def check_compatibility(pref_a, pref_b):
    """
    Checks if two students' preferences are compatible based on:
    1. Same learning style
    2. At least one overlapping availability period
    3. Same subject
    """
    if pref_a['learning_style'] != pref_b['learning_style']:
        return False

    if pref_a['subject'] != pref_b['subject']:
        return False

    for day_a, day_b in zip(pref_a['availability'], pref_b['availability']):
        if day_a > 0 and day_b > 0 and day_a == day_b:
            return True

    return False


def listen_for_udp(ip, port, preferences):
    """
    Listens for incoming UDP messages from peers and checks for preference compatibility.
    """
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_socket.bind((ip, port))
    print(f"Listening for UDP messages on {ip}:{port}...")

    while True:
        data, addr = udp_socket.recvfrom(1024)
        message = data.decode('utf-8')

        if message == "PING":
            udp_socket.sendto("PONG".encode('utf-8'), addr)
        else:
            other_data = json.loads(message)
            
            # Ignore messages from self
            if other_data['ip'] == ip and other_data['port'] == port:
                continue
            
            print(f"Received preferences from {addr}: {other_data['preferences']}")

            # Check compatibility
            if check_compatibility(preferences, other_data['preferences']):
                print(f"Compatible study buddy found at {addr[0]}:{addr[1]}!")
                print(f"Details: {other_data['preferences']}")


def send_preferences(ip, port, preferences):
    """
    Sends the client's preferences to the server for registration.
    """
    try:
        # Create a TCP socket for server registration
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect(('192.168.1.8', 12345))  # Replace with the server IP and port

        # Send preferences to the server
        data = {
            'ip': ip,
            'port': port,
            'preferences': preferences
        }
        client_socket.send(json.dumps(data).encode('utf-8'))

        # Receive server response
        response = client_socket.recv(1024).decode('utf-8')
        print(f"Server response: {response}")
    except Exception as e:
        print(f"Error sending preferences: {e}")
    finally:
        client_socket.close()


def broadcast_preferences(ip, port, preferences):
    """
    Broadcasts the client's preferences over UDP to peers.
    """
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

    # Include IP and port in the message to differentiate sender
    data = {
        'ip': ip,
        'port': port,
        'preferences': preferences
    }
    message = json.dumps(data).encode('utf-8')
    udp_socket.sendto(message, ('<broadcast>', 54321))  # Broadcast to all peers
    udp_socket.close()


if __name__ == "__main__":
    # Student-specific details
    ip = '192.168.1.8'  # Replace with your actual IP
    udp_port = 54322
    preferences = {
        'learning_style': 'a',
        'availability': [1, 1, -1, 1, 1, 1, 3],
        'subject': 'Mathematics'
    }

    # Start UDP listener thread
    udp_thread = threading.Thread(target=listen_for_udp, args=(ip, udp_port, preferences))
    udp_thread.daemon = True
    udp_thread.start()

    # Register with the server
    send_preferences(ip, udp_port, preferences)

    # Periodically broadcast preferences over UDP
    while True:
        broadcast_preferences(ip, udp_port, preferences)
        print("Broadcasting preferences...")
        time.sleep(5)  # Broadcast every 5 seconds
