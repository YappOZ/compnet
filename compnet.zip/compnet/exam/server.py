"""
Study Buddy Matching System
In a university, students need to find suitable study partners for collaborative learning. To support this need, the university introduces a decentralized system where students can connect to a peer-to-peer network to find study buddies based on their study preferences, subject and time availability. The preferences that a student must mention are: (learning style - one of the characters 'a' - for auditory, 'v' - for visual, 'h' - for hands on; availability - a list of 7 elements that contain, for each day of the week, the time interval during which the student is available for learning: -1 - not available, 1 - in the morning, 2- in the afternoon, 3- in the evening; subject - a string with maximum 32 characters).
The central server only maintains a directory of active students and updates each student when new students enter or exit the network. It does not directly facilitate the matching or communication between students. The central server updates students on new arrivals or departures, helping each student client maintain an updated list of potential study buddies in the network.
Each student connects over TCP to a central server to register for the budding matching system and to receive a list of other students currently in the network. When a student registers it sends to the server its IP address and port that he uses for UDP communication with its peers.
→ Once registered, each student's client application forms a peer-to-peer mesh network over UDP with the other students, allowing them to directly communicate and search for compatible study partners.
◆ Each student shares their preferences with the other students using the UDP connection.
When a student gets some data from another student that has compatible study preferences (same learning style, at least one day of the week in which they can study at the same period, and same subject), he displays the IP and the UDP port and exits the registration system.
Compatible Students Example:
Student A: v,[1, 2, -1, 3, -1, 2, 1], Mathematics
Student B: v, [1, -1, 3, -1, 2, -1, 1], Mathematics
Student A (learning style: v, availability: [1, 2, -1, 3, -1, 2, 1], subject: Mathematics) and Student B (learning style: v, availability: [1, -1, 3, -1, 2, -1, 1], subject: Mathematics) are compatible because they share the same learning style, subject, and have overlapping availability on Monday morning and Sunday morning.
Incompatible Students Example:
Student C: a, [1, -1, 3, 2, -1, -1, 1], Physics
Student D: v, [-1, 2, -1, 3, 1, 2, -1], Physics
Student C (learning style: a, availability: [1, -1, 3, 2, -1, -1, 1], subject: Physics) and Student D (learning style: v, availability: [-1, 2, -1, 3, 1, 2, -1], subject: Physics) are incompatible because their learning styles and availability do not match.
For the grade 5: a client sends to the server over TCP his/her study preferences. The server responds with a greeting message. Check every operation for errors and properly send the data.
"""

#----------------- server.py -----------------
import socket
import threading
import json

# Global variables
students = {}
lock = threading.Lock()


def handle_client(client_socket):
    global students
    try:
        # Receive data from client
        data = client_socket.recv(1024).decode('utf-8')
        data = json.loads(data)
        print(f"Received data from {data['ip']}:{data['port']} - {data['preferences']}")

        # Add the student to the directory
        lock.acquire()
        students[data['ip']] = data
        lock.release()

        # Send a greeting response
        response = "Hello, you are registered!"
        client_socket.send(response.encode('utf-8'))
    except Exception as e:
        print(f"Error handling client: {e}")
    finally:
        client_socket.close()


def notify_departures():
    global students
    while True:
        # Periodically clean up unreachable students
        with lock:
            to_remove = []
            for ip, student in students.items():
                try:
                    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    udp_socket.settimeout(1)
                    message = "PING".encode('utf-8')
                    udp_socket.sendto(message, (student['ip'], student['port']))
                    udp_socket.recvfrom(1024)
                except socket.timeout:
                    print(f"{ip}:{student['port']} is unreachable. Removing...")
                    to_remove.append(ip)
                finally:
                    udp_socket.close()
            for ip in to_remove:
                del students[ip]


def main():
    # Create TCP server socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('0.0.0.0', 12345))
    server_socket.listen(5)
    print("Server is running and listening for connections...")

    # Create a thread to handle periodic cleanup
    cleanup_thread = threading.Thread(target=notify_departures)
    cleanup_thread.daemon = True
    cleanup_thread.start()

    while True:
        # Accept new connections
        client_socket, addr = server_socket.accept()
        print(f"Connection from {addr}")
        
        # Handle the client in a new thread
        client_thread = threading.Thread(target=handle_client, args=(client_socket,))
        client_thread.daemon = True
        client_thread.start()


if __name__ == "__main__":
    main()
